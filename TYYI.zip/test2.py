for i in range(9,0,-2):
    print(i,end=' ')
print()